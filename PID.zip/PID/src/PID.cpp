#include "PID.h"

void PID::SetGains(float _Kp, float _Ki, float _Kd) {
	Kp = _Kp;
	Ki = _Ki;
	Kd = _Kd;
}

void PID::SetWindupGuard(float _Wg1, float _Wg2) {
	Wg1 = _Wg1;
	Wg2 = _Wg2;
}

void PID::SetSampleTime(unsigned int nst) {
	sampleTime = nst;
}

void PID::ChangeSampleTime(unsigned int nst) {
	float r = ((float)nst / (float)sampleTime);

	Ki *= r;
	Kd /= r;
	sampleTime = nst;
}

int PID::GetSampleTime() const {
	return sampleTime;
}

float PID::GetKp() const {
	return Kp;
}

float PID::GetKi() const {
	return Ki;
}

float PID::GetKd() const {
	return Kd;
}

float PID::GetWg1()const {
	return Wg1;
}

float PID::GetWg2()const {
	return Wg2;
}

void PID::Compute(float &pid, float &input, float &setpoint) { // calculate PID
	float deltaT = millis() - lastTime; // deltaT = actual time - time after computation
	if (deltaT >= sampleTime) { // if deltaT is equal to sample time do processing
		error = setpoint - input;

		if (abs(error) > epsilon) { // if the the error is too small stop integration
			integral += error;// rectangular integration
		}// end if

		derivative = (input - lastInput);

		P = Kp * error; // proportional component
		I = Ki * integral; // integral component
		D = Kd * derivative; // derivative component

		if (I > Wg1) I = Wg1; // windup guard integral
		if (I < Wg2)  I = Wg2;

		pid = P + I + D; //output PID value

		if (pid > Wg1)(pid) = Wg1; // windup guard output
		if (pid < Wg2)(pid) = Wg2;

		lastInput = input;		//update input
		lastTime = millis();	//update time

# if defined PRINT
		Serial.print(setpoint);
		Serial.print(",");
		Serial.print(input);
		Serial.print(",");
		Serial.println(pid);
#endif
	}// end if
}// end Compute();