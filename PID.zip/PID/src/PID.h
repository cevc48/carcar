/*************************************************************************
A PID controller is a feedback control loop that calculates an error
value as the difference between a setpoint and a measured variable in
a process.The PID controller minimizes the error by adjusting
the input.
The initialization constructor allows to declare an object globally before
the setup() function and to insert the PID settings.
				Version 1.1		Author: Carlos Carvalho
*************************************************************************/

#pragma once

#ifndef PID_H_INCLUDED
#define PID_H_INCLUDED

#if defined(ARDUINO) && ARDUINO >= 100
#include "arduino.h"
#else
#include "WProgram.h"
#endif

#define PRINT  // to output in csv
//format for debug purposes

class PID

{
public:

	PID() {
		sampleTime = 1000; //default sample time
	} // default constructor

	void SetGains(float, float, float);
	void SetWindupGuard(float, float);

	void SetSampleTime(unsigned int);
	void ChangeSampleTime(unsigned int);
	int GetSampleTime() const;
	float GetKp() const;
	float GetKi() const;
	float GetKd() const;
	float GetWg1()const;
	float GetWg2()const;
	void Compute(float &, float &, float &);
	~PID() {}; // destructor

private:
	float P, I, D;
	unsigned int sampleTime;
	unsigned long lastTime = 0.0;
	float lastInput;	// input after sample time
	float Kp, Ki, Kd;	 //gains for proportional, integral and derivative components
	float Wg1, Wg2;		// windup variables
	float error;		// error variable
	float epsilon = 0.01; // error treshold variable
	float integral = 0.0;
	float derivative;
};

#endif