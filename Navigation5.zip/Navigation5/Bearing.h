#pragma once

//calculate heading between two points
double Course(double lat1, double lon1, double lat2, double lon2) {
	lat1 *= DEG_TO_RAD;
	lat2 *= DEG_TO_RAD;
	lon1 *= DEG_TO_RAD;
	lon2 *= DEG_TO_RAD;

	double y = sin(lon1 - lon2)* cos(lat2);
	double x = cos(lat1)*sin(lat2) - sin(lat1)* cos(lat2)*cos(lon2 - lon1);

	double bearCalc = atan2(y, x)*RAD_TO_DEG;

	if (bearCalc <= 1) {
		bearCalc += 360;
	}

	return (360 - bearCalc);
}
//--------------------------------------------------------------------
// calculate distance between two points
double Distance(double lat1, double lon1, double lat2, double lon2) {
	double R = 6371000;
	double phi1 = radians(lat1);
	double phi2 = radians(lat2);

	double deltaPhi = (lat2 - lat1)*DEG_TO_RAD;
	double deltaLambda = (lon2 - lon1)*DEG_TO_RAD;

	double halfSinDeltaPhi = sin(deltaPhi*0.5);
	double halfSinDeltaLambda = sin(deltaLambda * 0.5);

	double alfa = halfSinDeltaPhi * halfSinDeltaPhi;

	double beta = cos(phi1)*cos(phi2)* halfSinDeltaLambda * halfSinDeltaLambda;

	double a = alfa + beta;

	double d = 2 * atan2(sqrt(a), sqrt(1 - a));

	return (R * d);
}
//-------------------------------------------------------
int RunAverage(double in) { // smoothing averaging filter
	const unsigned int n = 3;

	double a[n];

	for (int i = 0; i < n; i++) {
		a[n] += in;
	}

	return (a[n] / n);
}
